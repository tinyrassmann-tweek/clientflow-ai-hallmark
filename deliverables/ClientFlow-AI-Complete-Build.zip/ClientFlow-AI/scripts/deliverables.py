from pathlib import Path
import base64,re,zipfile,json
root=Path(__file__).resolve().parent.parent
out=root/'deliverables';out.mkdir(parents=True,exist_ok=True)
origin='https://clientflow-ai.tiny-rassmann.chatgpt.site'
def inline_assets(text):
 for p in (root/'public/assets').iterdir():
  mime='image/webp' if p.suffix=='.webp' else 'image/svg+xml'
  text=text.replace('/assets/'+p.name,'data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode())
 return text
def links(text):
 text=text.replace('href="/app','href="'+origin+'/app').replace('href="/login','href="'+origin+'/login')
 text=text.replace('href="/"','href="'+origin+'/"')
 return text
landing=(root/'public/index.html').read_text()
landing=re.sub(r'<link rel="preload"[^>]+>','',landing)
landing=re.sub(r'<link rel="manifest"[^>]+>','',landing)
landing=landing.replace('<link rel="stylesheet" href="/styles.css">','<style>'+((root/'public/tokens.css').read_text()+'\n'+(root/'public/base.css').read_text()+'\n'+(root/'public/styles.css').read_text().replace("@import url('./tokens.css');",'').replace("@import url('./base.css');",''))+'</style>')
script=(root/'public/landing.js').read_text().replace("e.preventDefault();if(!form.reportValidity())return;", "e.preventDefault();if(location.protocol==='file:'){status.innerHTML='To send your request, <a href=\""+origin+"/#start\">open the hosted ClientFlow page</a>. This downloaded copy is for preview.';return;}if(!form.reportValidity())return;")
landing=landing.replace('<script src="/landing.js" defer></script>','<script>'+script+'</script>')
(out/'ClientFlow-AI-Landing.html').write_text(links(inline_assets(landing)))
app=(root/'public/app.html').read_text()
app=app.replace('<link rel="stylesheet" href="/styles.css">','<style>'+((root/'public/tokens.css').read_text()+'\n'+(root/'public/base.css').read_text()+'\n'+(root/'public/styles.css').read_text().replace("@import url('./tokens.css');",'').replace("@import url('./base.css');",''))+'</style>').replace('<link rel="stylesheet" href="/app.css">','<style>'+(root/'public/app.css').read_text().replace("@import url('./tokens.css');",'')+'</style>')
app=re.sub(r'<link rel="manifest"[^>]+>','',app)
domain=(root/'public/domain.js').read_text().replace('export ','')
appjs=(root/'public/app.js').read_text();appjs=re.sub(r"import .*?;\n",'',appjs,count=1)
appjs=appjs.replace("const demo=new URLSearchParams(location.search).has('demo')",'const demo=true')
app=app.replace('<script type="module" src="/app.js"></script>','<script type="module">'+domain+'\n'+appjs+'</script>')
(out/'ClientFlow-AI-App-Preview.html').write_text(links(inline_assets(app)))
guide=(root/'LAUNCH-GUIDE.html').read_text()
(out/'ClientFlow-AI-Launch-Guide.html').write_text(guide)
with zipfile.ZipFile(out/'ClientFlow-AI-Complete-Build.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  rel=p.relative_to(root)
  if not p.is_file() or any(x in ['.git','.local','node_modules','deliverables'] for x in rel.parts) or p.name in ['qa.html','.env']:continue
  z.write(p,'ClientFlow-AI/'+str(rel))
 for name in ['ClientFlow-AI-Landing.html','ClientFlow-AI-App-Preview.html','ClientFlow-AI-Hallmark-Comparison.html']:
  z.write(out/name,'ClientFlow-AI/previews/'+name)
print(json.dumps([{'file':p.name,'bytes':p.stat().st_size} for p in out.iterdir()]))
