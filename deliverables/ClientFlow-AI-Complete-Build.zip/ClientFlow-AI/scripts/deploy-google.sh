#!/usr/bin/env bash
set -euo pipefail
: "${CF_PROJECT:?Set CF_PROJECT to your existing Google Cloud project ID}"
: "${CF_OWNER_EMAIL:?Set CF_OWNER_EMAIL to the owner account email}"
: "${CF_FIREBASE_API_KEY:?Set CF_FIREBASE_API_KEY to your Firebase web API key}"
CF_REGION="${CF_REGION:-us-east1}"
CF_SERVICE="${CF_SERVICE:-clientflow-ai}"
CF_ACCOUNT="clientflow-runtime@${CF_PROJECT}.iam.gserviceaccount.com"
command -v gcloud >/dev/null || { echo 'Run this from Google Cloud Shell, where gcloud is installed.' >&2; exit 1; }
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com firestore.googleapis.com identitytoolkit.googleapis.com --project="$CF_PROJECT"
if ! gcloud firestore databases describe --database='(default)' --project="$CF_PROJECT" >/dev/null 2>&1; then
  echo 'Create a Standard edition, Native mode (default) Firestore database in this project, then rerun. Choose the database location deliberately; it cannot be changed later.' >&2
  exit 1
fi
if ! gcloud iam service-accounts describe "$CF_ACCOUNT" --project="$CF_PROJECT" >/dev/null 2>&1; then
  gcloud iam service-accounts create clientflow-runtime --display-name='ClientFlow runtime' --project="$CF_PROJECT"
fi
gcloud projects add-iam-policy-binding "$CF_PROJECT" --member="serviceAccount:$CF_ACCOUNT" --role=roles/datastore.user --condition=None >/dev/null
gcloud run deploy "$CF_SERVICE" --source=. --region="$CF_REGION" --project="$CF_PROJECT" --service-account="$CF_ACCOUNT" --allow-unauthenticated --port=8080 --min-instances=0 --max-instances=3 --memory=512Mi --timeout=60 --set-env-vars="GOOGLE_CLOUD_PROJECT=$CF_PROJECT,FIREBASE_API_KEY=$CF_FIREBASE_API_KEY,BOOTSTRAP_OWNER_EMAIL=$CF_OWNER_EMAIL"
echo 'Deployment completed. Enable Firebase Email/Password authentication and verify the owner email before opening a saved workspace.'
