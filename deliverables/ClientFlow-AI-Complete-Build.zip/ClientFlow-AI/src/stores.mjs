export class D1Store {
 constructor(db){this.db=db;}
 async get(key){const r=await this.db.prepare('SELECT data, version FROM documents WHERE key=?').bind(key).first();return r?{value:JSON.parse(r.data),version:r.version}:null;}
 async create(key,value){const r=await this.db.prepare('INSERT OR IGNORE INTO documents (key,data,version) VALUES (?,?,1)').bind(key,JSON.stringify(value)).run();return r.meta.changes===1;}
 async cas(key,version,value){const r=await this.db.prepare('UPDATE documents SET data=?,version=version+1 WHERE key=? AND version=?').bind(JSON.stringify(value),key,version).run();return r.meta.changes===1;}
 async list(prefix,limit=1000){const r=await this.db.prepare('SELECT key,data,version FROM documents WHERE key>=? AND key<? ORDER BY key LIMIT ?').bind(prefix,prefix+'\uffff',limit).all();return r.results.map(x=>({key:x.key,value:JSON.parse(x.data),version:x.version}));}
}
export class FirestoreStore {
 constructor(project){if(!/^[a-z][a-z0-9-]{4,61}[a-z0-9]$/.test(project||''))throw Error('Set GOOGLE_CLOUD_PROJECT to your project ID.');this.root='https://firestore.googleapis.com/v1/projects/'+project+'/databases/(default)/documents';this.name='projects/'+project+'/databases/(default)/documents/clientflow/';this.token=null;}
 async headers(){if(!this.token||this.token.until<Date.now()){const r=await fetch('http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',{headers:{'Metadata-Flavor':'Google'}});if(!r.ok)throw Error('Cloud Run service identity unavailable');const t=await r.json();this.token={value:t.access_token,until:Date.now()+(t.expires_in-60)*1000};}return {Authorization:'Bearer '+this.token.value,'Content-Type':'application/json'};}
 unpack(d){return {key:d.fields.key.stringValue,value:JSON.parse(d.fields.data.stringValue),version:d.updateTime};}
 async get(key){const r=await fetch(this.root+'/clientflow/'+encodeURIComponent(key),{headers:await this.headers()});if(r.status===404)return null;if(!r.ok)throw Error('Database read failed');return this.unpack(await r.json());}
 async write(key,value,version){const fields={key:{stringValue:key},data:{stringValue:JSON.stringify(value)}};const r=await fetch(this.root+':commit',{method:'POST',headers:await this.headers(),body:JSON.stringify({writes:[{update:{name:this.name+key,fields},currentDocument:version?{updateTime:version}:{exists:false}}]})});if([400,409,412].includes(r.status)){const error=await r.json();if(['ALREADY_EXISTS','FAILED_PRECONDITION','ABORTED'].includes(error.error?.status))return false;throw Error('Database write rejected');}if(!r.ok)throw Error('Database write failed');return true;}
 create(key,value){return this.write(key,value,null);}
 cas(key,version,value){return this.write(key,value,version);}
 async list(prefix,limit=1000){const r=await fetch(this.root+':runQuery',{method:'POST',headers:await this.headers(),body:JSON.stringify({structuredQuery:{from:[{collectionId:'clientflow'}],where:{compositeFilter:{op:'AND',filters:[{fieldFilter:{field:{fieldPath:'key'},op:'GREATER_THAN_OR_EQUAL',value:{stringValue:prefix}}},{fieldFilter:{field:{fieldPath:'key'},op:'LESS_THAN',value:{stringValue:prefix+'\uffff'}}}]}},orderBy:[{field:{fieldPath:'key'},direction:'ASCENDING'}],limit}})});if(!r.ok)throw Error('Database query failed');return (await r.json()).filter(x=>x.document).map(x=>this.unpack(x.document));}
}
